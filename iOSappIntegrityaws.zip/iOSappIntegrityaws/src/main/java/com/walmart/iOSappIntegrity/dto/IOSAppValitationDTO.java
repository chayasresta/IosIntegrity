package com.walmart.iOSappIntegrity.dto;

import lombok.Data;

@Data
public class IOSAppValitationDTO {

    private String message;
    private boolean appIntegrityStatus;

}
