package com.walmart.iOSappIntegrity.api;

import org.bouncycastle.asn1.*;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECPoint;
import java.util.Arrays;
import java.util.Base64;
@Component
public class AttestationUtils {

    //step no. 2 & 3 from listed Nine steps
    public byte[] appendAuthDataAndChallageAndGenerateNonce(String oneTimeChallage, String authData1) {
        byte[] oneTimeChallenge = oneTimeChallage.getBytes(StandardCharsets.UTF_8);
        byte[] authDataBytes = hexStringToByteArray(authData1);

        try {
            // Step 1: Calculate clientDataHash
            byte[] clientDataHash = sha256Hash(oneTimeChallenge);
            //System.out.println("ClientDataHash: " + toBase64(clientDataHash));

            // Append clientDataHash to authData
            System.out.println("aaaaaa "+authData1);
            byte[] authDataWithHash = concatenateBytes(authDataBytes, clientDataHash);
            System.out.println("step44444   "+toBase64(authDataBytes));
            System.out.println("ClientDataHash: " + toBase64(authDataWithHash));

            // Step 2: Generate nonce
            byte[] nonce = sha256Hash(authDataWithHash);
            System.out.println("Nonce: " + toBase64(nonce));

            return nonce;

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    private byte[] sha256Hash(byte[] data) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return digest.digest(data);
    }

    private byte[] concatenateBytes(byte[] arr1, byte[] arr2) {
        byte[] concatenated = new byte[arr1.length + arr2.length];
        System.arraycopy(arr1, 0, concatenated, 0, arr1.length);
        System.arraycopy(arr2, 0, concatenated, arr1.length, arr2.length);
        return concatenated;
    }


    // Method to convert byte array to Base64 string
    private static String toBase64(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }

    //step no. 4 from listed Nine steps

    /**
     * 4. Obtain the value of the credCert extension with OID 1.2.840.113635.100.8.2, which is a DER-encoded ASN.1 sequence.
     * Decode the sequence and extract the single octet string that it contains. Verify that the string equals nonce.
     */
    // Method to extract credCert extension value from the certificate

    public byte[] extractCredCertExtensionValue(byte[] certBytes, byte[] nonce) throws CertificateException, IOException {
        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
        X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream(certBytes));

        byte[] credCertExtensionValue = null;

        // Extract credCert extension value
        byte[] extensionValue = certificate.getExtensionValue("1.2.840.113635.100.8.2");

        if (extensionValue != null && extensionValue.length > 2) {
            // Skip the first two bytes (tag and length)
            credCertExtensionValue = Arrays.copyOfRange(extensionValue, 2, extensionValue.length);
            System.out.println("CredCertExtensionValue : " + Base64.getEncoder().encodeToString(credCertExtensionValue));
        }

        byte[] decodedOctetString = null;

        if (credCertExtensionValue != null) {
            // Decode the DER-encoded ASN.1 sequence to get the octet string
            decodedOctetString = decodeDEROctetStringNew(credCertExtensionValue);

            if (decodedOctetString != null) {
                System.out.println("DecodedOctetString : " + Base64.getEncoder().encodeToString(decodedOctetString));

                // Verify that the extracted octet string matches the nonce
                if (Arrays.equals(decodedOctetString, nonce)) {
                    System.out.println("Step 4: Nonce verification successful.");
                } else {
                    //System.out.println("Step 4: Nonce verification failed.");
                    throw new IOSException("Step 4: Nonce verification failed.");
                }
            }
        }
        return decodedOctetString;
    }

    public byte[] decodeDEROctetStringNew(byte[] encodedData) throws IOException {
        try (ASN1InputStream asn1InputStream = new ASN1InputStream(new ByteArrayInputStream(encodedData))) {
            ASN1Primitive asn1Primitive = asn1InputStream.readObject();
            if (asn1Primitive instanceof ASN1Sequence) {
                ASN1Sequence sequence = (ASN1Sequence) asn1Primitive;
                for (int i = 0; i < sequence.size(); i++) {
                    ASN1Primitive element = sequence.getObjectAt(i).toASN1Primitive();
                    System.out.println("Element " + i + ": " + element.getClass().getName());
                    if (element instanceof DEROctetString) {
                        byte[] octets = ((DEROctetString) element).getOctets();
                        System.out.println("Octet String: " + bytesToHex(octets)); // Print octet string as hex
                        return octets;
                    } else if (element instanceof DLTaggedObject) {
                        DLTaggedObject taggedObject = (DLTaggedObject) element;
                        ASN1Primitive taggedObjectContent = taggedObject.getObject();
                        if (taggedObjectContent instanceof DEROctetString) {
                            byte[] octets = ((DEROctetString) taggedObjectContent).getOctets();
                            System.out.println("Octet String: " + toBase64(octets)); // Print octet string as hex
                            return octets;
                        }
                    }
                }
            } else if (asn1Primitive instanceof DEROctetString) {
                byte[] octets = ((DEROctetString) asn1Primitive).getOctets();
                System.out.println("Octet String: " + toBase64(octets)); // Print octet string as hex
                return octets;
            }
        }
        return null; // Return null if no valid octet string found
    }


    //step no. 5 from listed Nine steps
    /*Create the SHA256 hash of the public key in credCert, and verify that it matches the key identifier
    from your app.
     */

    public static String veriftyPublicKeyWithKeyIdentifier(byte[] credCertBytes) throws Exception {
        byte[] publicKeyBytes = null;

            // Create X509Certificate from credCert bytes
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            X509Certificate credCert = (X509Certificate) certFactory.generateCertificate(new ByteArrayInputStream(credCertBytes));

            // Get the public key from credCert
            PublicKey publicKey = credCert.getPublicKey();

            if (!(publicKey instanceof ECPublicKey)) {
                throw new IllegalArgumentException("Public key is not an EC key");
            }

            ECPublicKey ecPublicKey = (ECPublicKey) publicKey;
            ECPoint ecPoint = ecPublicKey.getW();
            int fieldSize = (ecPublicKey.getParams().getCurve().getField().getFieldSize() + 7) / 8;

            byte[] x = ecPoint.getAffineX().toByteArray();
            byte[] y = ecPoint.getAffineY().toByteArray();

            // Ensure the arrays are the correct length
            x = adjustArray(x, fieldSize);
            y = adjustArray(y, fieldSize);

            byte[] encodedPublicKey = new byte[1 + 2 * fieldSize];
            encodedPublicKey[0] = 0x04; // Uncompressed point format
            System.arraycopy(x, 0, encodedPublicKey, 1, fieldSize);
            System.arraycopy(y, 0, encodedPublicKey, 1 + fieldSize, fieldSize);

            // Calculate SHA256 hash of the encoded public key
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] publicKeyHash = digest.digest(encodedPublicKey);

            // Encode the publicKeyHash to Base64
            String publicKeyHashBase64 = Base64.getEncoder().encodeToString(publicKeyHash);
         //   System.out.println("Expected key identifier: " + keyIdentifier);
            System.out.println("Step 5. Calculated public key hash (Base64): " + publicKeyHashBase64);

            // Compare publicKeyHash with expectedKeyIdentifier
/*            if (keyIdentifier.equals(publicKeyHashBase64)) {
                System.out.println("Step 5: Public key hash matches the expected key identifier");
            } else {
                throw new Exception("Public key hash does not matches the expected key identifier");
            }*/

        return publicKeyHashBase64;
    }

    private static byte[] adjustArray(byte[] array, int requiredLength) {
        if (array.length == requiredLength) {
            return array;
        } else if (array.length > requiredLength) {
            return Arrays.copyOfRange(array, array.length - requiredLength, array.length);
        } else {
            byte[] paddedArray = new byte[requiredLength];
            System.arraycopy(array, 0, paddedArray, requiredLength - array.length, array.length);
            return paddedArray;
        }
    }


    //step no. 6 from listed Nine steps
    /*Compute the SHA256 hash of your app’s App ID, and verify that it’s the same as the authenticator
    data’s RP ID hash
     */

    public static void verifyRpIdHash(String appId, String authDataHex) throws Exception {


            System.out.println("Steppp 66 "+authDataHex);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(appId.getBytes(StandardCharsets.UTF_8));

            byte[] appIdHash = computeSHA256(appId.getBytes(StandardCharsets.UTF_8));

            System.out.println("Computed SHA-256 Hash111: "+ hash);
            // Extract RP ID hash from authenticator data
            byte[] authDataBytes = hexStringToByteArray(authDataHex);

            byte[] rpIdHash = extractRpIdHash(authDataBytes);

            // Debug: Print computed SHA-256 hash and extracted RP ID hash
            System.out.println("Computed SHA-256 Hash: " + Arrays.toString(appIdHash));
            System.out.println("Extracted RP ID Hash: " + Arrays.toString(rpIdHash));
            String rpIdBase64 = Base64.getEncoder().encodeToString(rpIdHash);
            // Compare hashes
            if (Arrays.equals(appIdHash, rpIdHash)) {
                System.out.println("RP ID hash verification successful.");
            } else {
                throw new AttestationException.InvalidAuthenticatorData("App ID does not match RP ID hash");
            }

    }


    // Custom exception for attestation errors
    static class AttestationException extends RuntimeException {
        public AttestationException(String message) {
            super(message);
        }

        static class InvalidAuthenticatorData extends AttestationException {
            public InvalidAuthenticatorData(String message) {
                super(message);
            }
        }
    }


    // Helper method to extract RP ID hash from authenticator data
    public static byte[] extractRpIdHash(byte[] authData) {
        // Ensure authData is not null and is of valid length
        if (authData == null || authData.length < 32) { // Adjust based on your data structure
            throw new IllegalArgumentException("Invalid authenticator data");
        }

        // Since your authData seems to be a straightforward RP ID hash representation
        // Let's use the full authData as RP ID hash if it's exactly 32 bytes
        if (authData.length == 32) {
            return authData;
        }

        // Extract RP ID hash from the correct location within authData
        // Adjust the extraction logic as needed for your specific data structure
        byte[] rpIdHash = Arrays.copyOfRange(authData, 0, 32); // Adjust the range based on your data structure

        return rpIdHash;
    }

    // Method to compute SHA-256 hash
    public static byte[] computeSHA256(byte[] input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return digest.digest(input);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }


    //step no. 7 from listed Nine steps
    /*Compute the SHA256 hash of your app’s App ID, and verify that it’s the same as the authenticator
    data’s RP ID hash
     */
    public void getAuthSignCount(byte[] authData) throws Exception {
        byte[] authenticatorData = authData;//authData.getBytes(); // Replace with the authenticator data

        // Parse the authenticator data to extract the counter field
        int counter = parseCounter(authenticatorData);

        // Verify if the counter equals 0
        if (counter == 0) {
            System.out.println(" Step 7: Verification successful! The authenticator data's counter field equals 0.");
        } else {
            throw new Exception("Verification failed! The authenticator data's counter field does not equal 0.");
        }
    }

    private static int parseCounter(byte[] authenticatorData) {
        // Authenticator data format: [rpIdHash(32 bytes)][flags(1 byte)][counter(4 bytes)]
        ByteBuffer buffer = ByteBuffer.wrap(authenticatorData);

        // Skip rpIdHash (32 bytes) and flags (1 byte)
        buffer.position(33);

        // Read counter (4 bytes)
        return buffer.getInt();
    }

    //step no. 8 from listed Nine steps
    /*Verify that the authenticator data’s aaguid field is either appattestdevelop if operating in the
    development environment, or appattest followed by seven 0x00 bytes if operating in the production environment.
     */

    // Method to verify the aaguid
    public static void verifyAaguid(String authDataHex, String environment) throws Exception {
        // Converts a hex string to a byte array
        byte[] authDataBytes = hexStringToByteArray(authDataHex);

        // Debug: Print converted byte array
        System.out.println("Authenticator Data Bytes: " + Arrays.toString(authDataBytes));
        System.out.println("Authenticator Data Length: " + authDataBytes.length);

        // Extracts the aaguid from authenticator data
        byte[] aaguid = extractAaguid(authDataBytes);

        // Debug: Print extracted aaguid
        System.out.println("Extracted AAGUID: " + Arrays.toString(aaguid));

        // Verifies the aaguid based on the environment
        byte[] expectedAaguid;

        if ("development".equalsIgnoreCase(environment)) {
            expectedAaguid = new byte[16];
            System.arraycopy("appattestdevelop".getBytes(), 0, expectedAaguid, 0, 16);
        } else if ("production".equalsIgnoreCase(environment)) {
            expectedAaguid = new byte[16];
            System.arraycopy("appattest".getBytes(), 0, expectedAaguid, 0, 9);
            // The remaining 7 bytes are already zeroes, no need to explicitly set them
        } else {
            throw new IllegalArgumentException("Unknown environment: " + environment);
        }

        // Debug: Print expected aaguid
        System.out.println("Expected AAGUID: " + Arrays.toString(expectedAaguid));

        if (Arrays.equals(aaguid, expectedAaguid)) {
            System.out.println("STEP 8: AAGUID verification successful for " + environment + " environment.");
        } else {
            throw new Exception("AAGUID verification failed for " + environment + " environment.");
        }
    }
    public static byte[] extractAaguid(byte[] authData) {
        // Ensure authData is not null and is of valid length
        if (authData == null || authData.length < 53) {
            throw new IllegalArgumentException("Invalid authenticator data");
        }

        // AAGUID is located at offset 37 in the authenticator data
        int aaguidStart = 37;
        if (authData.length < aaguidStart + 16) {
            throw new IllegalArgumentException("Authenticator data too short to contain aaguid");
        }

        // Debug: Print data from offset 37 to check if we're aligned correctly
        System.out.println("Data from offset 37: " + Arrays.toString(Arrays.copyOfRange(authData, 37, authData.length)));

        return Arrays.copyOfRange(authData, aaguidStart, aaguidStart + 16);
    }
    // Helper method to convert hex string to byte array
    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

    //step no. 9 from listed Nine steps
    /*Verify that the authenticator data’s credentialId field is the same as the key identifier
     */
    //String authData2 = "dc5cecc5f1246483bcd5523ce7aede0cc4b21b651f8b58272930a32600090a554000000000617070617474657374646576656c6f700020b8fa6b128686af3d9e311995084b1258c2b837df0db86ab77c1a4ff978af2e19a50102032620012158201c113ffed8f01378128b5374b4401fc663ffd878f04d0ec568b40c3477cd0ac3225820dd6dd4f99dab13e547ea821f9c7c820d8bbe70fcc250cd5a1969f6dd8fdaba54";
    public static void verifyCredentialId(String authDataHex, byte[] expectedKeyIdentifierBytes) throws Exception {
        // Convert authenticator data from hex to byte array
        byte[] authDataBytes = hexStringToByteArray(authDataHex);

        // Extract credential ID from authenticator data
        byte[] credentialId = extractCredentialId(authDataBytes);

        // Debug: Print extracted credential ID and expected key identifier
        System.out.println("Extracted Credential ID: " + Arrays.toString(credentialId));
        System.out.println("Expected Key Identifier: " + Arrays.toString(expectedKeyIdentifierBytes));

        // Compare credential ID with expected key identifier
        if (Arrays.equals(credentialId, expectedKeyIdentifierBytes)) {
            System.out.println("Step 9: Credential ID verification successful.");
        } else {
            throw new Exception("Step 9:  Credential ID verification failed.");
        }
    }
    // Helper method to convert hexadecimal string to byte array
    public static byte[] extractCredentialId(byte[] authData) {
        // Ensure authData is not null and is of valid length
        if (authData == null || authData.length < 55) {
            throw new IllegalArgumentException("Invalid authenticator data");
        }

        // Credential ID length is located at offset 53 in the authenticator data
        int credentialIdLengthStart = 53;
        int credentialIdLength = ((authData[credentialIdLengthStart] & 0xFF) << 8) | (authData[credentialIdLengthStart + 1] & 0xFF);

        // Credential ID is located immediately after the credentialIdLength field
        int credentialIdStart = credentialIdLengthStart + 2;
        if (authData.length < credentialIdStart + credentialIdLength) {
            throw new IllegalArgumentException("Authenticator data too short to contain credential ID");
        }

        return Arrays.copyOfRange(authData, credentialIdStart, credentialIdStart + credentialIdLength);
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

}


