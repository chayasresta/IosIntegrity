package com.walmart.iOSappIntegrity.dto;

import lombok.Data;

@Data
public class AttestationDto {
    private String attestationObject;
    private String challenge;
    private String keyIdentifier;

    public AttestationDto(String attestationObject, String challenge, String keyIdentifier) {
        this.attestationObject = attestationObject;
        this.challenge = challenge;
        this.keyIdentifier = keyIdentifier;
    }
}

