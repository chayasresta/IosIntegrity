package com.walmart.iOSappIntegrity.api;


import com.walmart.iOSappIntegrity.dto.AttestationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

@RestController
public class AppServerConnect {

    @Autowired
    private AppleAppAttestDecoder appleAppAttestDecoder;

    @GetMapping("/generateServerChallenge")
    public static String generateServerChallenge() throws NoSuchAlgorithmException {
        SecureRandom secureRandom = new SecureRandom();
        byte[] challenge = new byte[16];
        secureRandom.nextBytes(challenge);
        return MessageDigest.getInstance("SHA-256").digest(challenge).toString();
    }


    @PostMapping("/validateAttestation")
    public ResponseEntity<String> validateAttestation(@RequestBody AttestationDto attestationDto) {
      //  appleAppAttestDecoder.validateAttestation("attestationDto","challenge", "keyIdentifier");
        return new ResponseEntity<>("Attestation Object Validated successfully", HttpStatus.CREATED);
    }


    @GetMapping("/receipts")
    public ResponseEntity<String> getReceipt() {
        // Create a RestTemplate instance
        RestTemplate restTemplate = new RestTemplate();

        // Set the request headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Make the GET request to the external API
        ResponseEntity<String> responseEntity = restTemplate.exchange("https://data-development.appattest.apple.com", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        // Return the response from the external API
        return new ResponseEntity<>(responseEntity.getBody(), responseEntity.getStatusCode());
    }

    public static String makeCert(byte[] bindata) {
        String beginPem = "-----BEGIN CERTIFICATE-----\n";
        String endPem = "-----END CERTIFICATE-----\n";

        // Base64 encode the binary data
        String cbenc = Base64.getEncoder().encodeToString(bindata);

        StringBuilder pemBuilder = new StringBuilder();
        pemBuilder.append(beginPem);

        // Insert newline characters every 64 characters
        int len = cbenc.length();
        for (int i = 0; i < len; i += 64) {
            pemBuilder.append(cbenc, i, Math.min(len, i + 64));
            pemBuilder.append("\n");
        }

        pemBuilder.append(endPem);

        return pemBuilder.toString();
    }

    public static void main(String[] args) {
        // Example usage:

        String base64String = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnVvb68JpMxUf+GSmy/19BlVRbgBiK/Uhz5eFNUgm0gRme0BJnL5he2W5GRhF+zpz8ZEpYf9PLn0yobKPOn5ic7pqsMhsEcsVs/WqCqVDyr7I0Ft1NgC4E0YzGCiwHvJwEo/I8gx58gRZzrgnIuPbEXDlk3iueLP8r8trREMYtD6e9eyCqF2nYDQ57Z4ToLQdtvB4BubF8FGgfKtLVz4AjeAqYGGoxp8NQpDvzRd+YgV6Zg0tZFYkZ5S5R/2GCPShlFqZfvSeSj3YJ4zTC6D6k7VNL7oKd+fnk3eSZ8zPT1G3at4o9hNmZzH7vLo9pAW4bPZwIDAQAB";

        // Decode the Base64 string to byte[]
        byte[] bindata = Base64.getDecoder().decode(base64String);

        String pemCert = makeCert(bindata);
        System.out.println(pemCert);
    }

}
