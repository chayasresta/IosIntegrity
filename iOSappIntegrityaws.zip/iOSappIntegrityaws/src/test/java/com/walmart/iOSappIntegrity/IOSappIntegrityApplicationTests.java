package com.walmart.iOSappIntegrity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IOSappIntegrityApplicationTests {

	@Test
	void contextLoads() {
	}

}
