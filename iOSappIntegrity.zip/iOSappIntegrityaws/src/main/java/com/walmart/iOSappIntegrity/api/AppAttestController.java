package com.walmart.iOSappIntegrity.api;

import com.walmart.iOSappIntegrity.dto.AttestationDto;
import com.walmart.iOSappIntegrity.dto.IOSAppValitationDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/IOSAppAttest/api")
public class AppAttestController {

    @Autowired
    private AppleAppAttestDecoder appleAppAttestDecoder;

    @PostMapping("/validate")
    public ResponseEntity<IOSAppValitationDTO> validateAttestation(@RequestBody AttestationDto attestationDto) {

        String challenge = "WalmartAppAttestation123";
        IOSAppValitationDTO responseDto = appleAppAttestDecoder.validateAttestation(attestationDto.getAttestationObject(), challenge);
        if(responseDto.isAppIntegrityStatus()) {
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
        }

    }

    @ExceptionHandler(IOSException.class)
    public ResponseEntity<String> handleCustomException(IOSException ex) {
        return ResponseEntity.badRequest().body(ex.getMessage());
    }
}
