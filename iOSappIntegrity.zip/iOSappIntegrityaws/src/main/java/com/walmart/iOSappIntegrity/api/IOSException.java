package com.walmart.iOSappIntegrity.api;


public class IOSException extends RuntimeException {
    private String message;

    public IOSException(String message) {
        super(message);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}