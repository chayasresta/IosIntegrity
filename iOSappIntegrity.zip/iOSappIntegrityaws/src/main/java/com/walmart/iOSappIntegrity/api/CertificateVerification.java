package com.walmart.iOSappIntegrity.api;

import org.springframework.stereotype.Component;

import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.List;

@Component
public class CertificateVerification {

    public static X509Certificate generateCertificateFromBytes(byte[] certBytes) throws CertificateException {
        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
        return (X509Certificate) certFactory.generateCertificate(new ByteArrayInputStream(certBytes));
    }

    public static void verifyCertificateChain(List<X509Certificate> certs) throws Exception {
        // Load Apple's App Attest root certificate
        X509Certificate rootCert = loadRootCertificate();

        // Create a KeyStore with the root certificate
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null, null);
        keyStore.setCertificateEntry("apple-app-attest-root", rootCert);

        // Initialize TrustManagerFactory with the KeyStore
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(keyStore);

        // Get the X509TrustManager
        X509TrustManager trustManager = (X509TrustManager) tmf.getTrustManagers()[0];

        // Convert List<X509Certificate> to X509Certificate[]
        X509Certificate[] certArray = new X509Certificate[certs.size()];
        certs.toArray(certArray);

        // Verify the certificate chain
        trustManager.checkServerTrusted(certArray, "ECDHE_ECDSA");
        System.out.println("Certificate chain validated successfully.");
    }

    public static X509Certificate loadRootCertificate() throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader("/home/ec2-user/IosIntegrity/iOSappIntegrityaws/src/main/resources/Apple_App_Attestation_Root_CA.pem"))) {
            StringBuilder pemString = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                pemString.append(line).append("\n");
            }
            String pemCert = pemString.toString();

            // Remove the first and last lines
            pemCert = pemCert.replace("-----BEGIN CERTIFICATE-----", "")
                    .replace("-----END CERTIFICATE-----", "")
                    .replaceAll("\\s", "");

            // Decode the Base64 string
            byte[] decodedBytes = Base64.getDecoder().decode(pemCert);

            // Generate the X509Certificate from the decoded bytes
            return generateCertificateFromBytes(decodedBytes);
        }
    }
}

