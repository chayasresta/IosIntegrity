package com.walmart.iOSappIntegrity.api;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.Base64;

public class Validate {

    public static void main(String[] args) throws Exception {

        String pemFilePath = "/Users/vn577di/Downloads/Apple_App_Attestation_Root_CA.pem"; // Replace with your actual file path

        X509Certificate certificate = parsePEMAndGetCertificate(readPEMFileAsString(pemFilePath));

        try {
            certificate.checkValidity(); // Validate the certificate
            System.out.println("Apple PEM Certificate is valid.");
        } catch (CertificateExpiredException | CertificateNotYetValidException e) {
            System.out.println("Certificate is not valid: " + e.getMessage());
        }

    }

    public static String readPEMFileAsString(String pemFilePath) throws IOException {
        byte[] bytes = Files.readAllBytes(Paths.get(pemFilePath));
        return new String(bytes);
    }

    public static X509Certificate parsePEMAndGetCertificate(String pemContent) throws Exception {
        // Remove the first and last lines if present (-----BEGIN CERTIFICATE----- and -----END CERTIFICATE-----)
        pemContent = pemContent.replaceAll("-----BEGIN CERTIFICATE-----", "")
                .replaceAll("-----END CERTIFICATE-----", "")
                .replaceAll("\\s", "");

        byte[] decoded = Base64.getDecoder().decode(pemContent);

        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
        return (X509Certificate) certFactory.generateCertificate(new ByteArrayInputStream(decoded));
    }
}
