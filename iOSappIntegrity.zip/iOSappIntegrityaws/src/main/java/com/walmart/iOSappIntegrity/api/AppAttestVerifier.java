package com.walmart.iOSappIntegrity.api;

import com.upokecenter.cbor.CBORObject;

import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class AppAttestVerifier {

    private static final String APPLE_APP_ATTEST_ROOT_CERT_PEM = "-----BEGIN CERTIFICATE-----\n" +
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7VVd7yvjPB2R6gcnUmJf\n" +
            "RMM68u5CZRYGZ8w1M5Uwns9bT4D1n/1hsrfTePc3qbyOD1eCl9wgez0ZUYloMNXQ\n" +
            "WMyAa+YcAD5lCGhP8MV7TjOpd9czxttO7Q1qu6Df3+6K0ljZyJmJUJ0EeFb/pkzR\n" +
            "8Z1AcjZDntmz3pWT1//WzTrfbcGfwbK43DAXnHTf7OK0A5V5MxP7J4IYJxqY68eU\n" +
            "Z3j2MRpCpUOvIR72D85DlLil9E0ALsF6IF//zPAmOdRh7Za4X5CgsDkzyRhsGuwW\n" +
            "nLp1AnW+1hFLB0VYh0Ugrq1PQxVwM9LUn7B3qR1E2J4F++ld2J7Qy2DTxcuqJLwI\n" +
            "DAQAB\n" +
            "-----END CERTIFICATE-----";

    public static void main(String[] args) throws Exception {
        // Base64 encoded attestation object
        String base64String = "o2NmbXRvYXBwbGUtYXBwYXR0ZXN0Z2F0dFN0bXSiY3g1Y4JZAyowggMmMIICrKADAgECAgYBkDUCubswCgYIKoZIzj0EAwIwTzEjMCEGA1UEAwwaQXBwbGUgQXBwIEF0dGVzdGF0aW9uIENBIDExEzARBgNVBAoMCkFwcGxlIEluYy4xEzARBgNVBAgMCkNhbGlmb3JuaWEwHhcNMjQwNjE5MDkzODA5WhcNMjUwNTA0MTg1MjA5WjCBkTFJMEcGA1UEAwxAMGNhNzdjYWViNjVkOTRmMmI1ODdlOWJmNjcyMDczOTA5NzZhYzQxN2I1YjkxOTBiNDYxZDRhYzg5NjY5NWQ2ZjEaMBgGA1UECwwRQUFBIENlcnRpZmljYXRpb24xEzARBgNVBAoMCkFwcGxlIEluYy4xEzARBgNVBAgMCkNhbGlmb3JuaWEwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAASAxB/VileDjziwMMldWRXIvXvZvOWpQ3ALYCqWP+n0mm4CEOw+yp8M4H5MIT1BAXq1e16UsG8QakmL0ZEXM/NQo4IBLzCCASswDAYDVR0TAQH/BAIwADAOBgNVHQ8BAf8EBAMCBPAwfQYJKoZIhvdjZAgFBHAwbqQDAgEKv4kwAwIBAb+JMQMCAQC/iTIDAgEBv4kzAwIBAb+JNB4EHERYWjVWRjg4MzYuY29tLndhbG1hcnQuc3dpZnSlBgQEc2tzIL+JNgMCAQW/iTcDAgEAv4k5AwIBAL+JOgMCAQC/iTsDAgEAMFcGCSqGSIb3Y2QIBwRKMEi/ingIBAYxNy41LjG/iFAHAgUA/////7+KewcEBTIxRjkwv4p9CAQGMTcuNS4xv4p+AwIBAL+LDA8EDTIxLjYuOTAuMC4wLDAwMwYJKoZIhvdjZAgCBCYwJKEiBCCqIIjfzs8NllYdbNU/uafw31kfQGWy/sn+If4Le7dzYjAKBggqhkjOPQQDAgNoADBlAjEAoOfDCk4W8y+gdHNxzc9IK+bttB2KMxVdah0wnBpHmU8NCGXqyTUQmzvIxgwx+XNQAjA3/av38efdTSFY8bL5AsMgbs+/Pow6mihmZbi3t2Ce4cK6cf14gE4vGCSUjmYMQ1BZAkcwggJDMIIByKADAgECAhAJusXhvEAa2dRTlbw4GghUMAoGCCqGSM49BAMDMFIxJjAkBgNVBAMMHUFwcGxlIEFwcCBBdHRlc3RhdGlvbiBSb290IENBMRMwEQYDVQQKDApBcHBsZSBJbmMuMRMwEQYDVQQIDApDYWxpZm9ybmlhMB4XDTIwMDMxODE4Mzk1NVoXDTMwMDMxMzAwMDAwMFowTzEjMCEGA1UEAwwaQXBwbGUgQXBwIEF0dGVzdGF0aW9uIENBIDExEzARBgNVBAoMCkFwcGxlIEluYy4xEzARBgNVBAgMCkNhbGlmb3JuaWEwdjAQBgcqhkjOPQIBBgUrgQQAIgNiAASuWzegd015sjWPQOfR8iYm8cJf7xeALeqzgmpZh0/40q0VJXiaomYEGRJItjy5ZwaemNNjvV43D7+gjjKegHOphed0bqNZovZvKdsyr0VeIRZY1WevniZ+smFNwhpmzpmjZjBkMBIGA1UdEwEB/wQIMAYBAf8CAQAwHwYDVR0jBBgwFoAUrJEQUzO9vmhB/6cMqeX66uXliqEwHQYDVR0OBBYEFD7jXRwEGanJtDH4hHTW4eFXcuObMA4GA1UdDwEB/wQEAwIBBjAKBggqhkjOPQQDAwNpADBmAjEAu76IjXONBQLPvP1mbQlXUDW81ocsP4QwSSYp7dH5FOh5mRya6LWu+NOoVDP3tg0GAjEAqzjt0MyB7QCkUsO6RPmTY2VT/swpfy60359evlpKyraZXEuCDfkEOG94B7tYlDm3Z3JlY2VpcHRZDpMwgAYJKoZIhvcNAQcCoIAwgAIBATEPMA0GCWCGSAFlAwQCAQUAMIAGCSqGSIb3DQEHAaCAJIAEggPoMYIETTAkAgECAgEBBBxEWFo1VkY4ODM2LmNvbS53YWxtYXJ0LnN3aWZ0MIIDNAIBAwIBAQSCAyowggMmMIICrKADAgECAgYBkDUCubswCgYIKoZIzj0EAwIwTzEjMCEGA1UEAwwaQXBwbGUgQXBwIEF0dGVzdGF0aW9uIENBIDExEzARBgNVBAoMCkFwcGxlIEluYy4xEzARBgNVBAgMCkNhbGlmb3JuaWEwHhcNMjQwNjE5MDkzODA5WhcNMjUwNTA0MTg1MjA5WjCBkTFJMEcGA1UEAwxAMGNhNzdjYWViNjVkOTRmMmI1ODdlOWJmNjcyMDczOTA5NzZhYzQxN2I1YjkxOTBiNDYxZDRhYzg5NjY5NWQ2ZjEaMBgGA1UECwwRQUFBIENlcnRpZmljYXRpb24xEzARBgNVBAoMCkFwcGxlIEluYy4xEzARBgNVBAgMCkNhbGlmb3JuaWEwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAASAxB/VileDjziwMMldWRXIvXvZvOWpQ3ALYCqWP+n0mm4CEOw+yp8M4H5MIT1BAXq1e16UsG8QakmL0ZEXM/NQo4IBLzCCASswDAYDVR0TAQH/BAIwADAOBgNVHQ8BAf8EBAMCBPAwfQYJKoZIhvdjZAgFBHAwbqQDAgEKv4kwAwIBAb+JMQMCAQC/iTIDAgEBv4kzAwIBAb+JNB4EHERYWjVWRjg4MzYuY29tLndhbG1hcnQuc3dpZnSlBgQEc2tzIL+JNgMCAQW/iTcDAgEAv4k5AwIBAL+JOgMCAQC/iTsDAgEAMFcGCSqGSIb3Y2QIBwRKMEi/ingIBAYxNy41LjG/iFAHAgUA/////7+KewcEBTIxRjkwv4p9CAQGMTcuNS4xv4p+AwIBAL+LDA8EDTIxLjYuOTAuMC4wLDAwMwYJKoZIhvdjZAgCBCYwJKEiBCCqIIjfzs8NllYdbNU/uafw31kfQGWy/sn+If4Le7dzYjAKBggqhkjOPQQDAgNoADBlAjEAoOfDCk4W8y+gdHNxzc9IK+bttB2KMxVdah0wnBpHmU8NCGXqyTUQmzvIxgwx+XNQAjA3/av38efdTSFY8bL5AsMgbs+/Pow6mihmZbi3t2Ce4cK6cf14gE4vGCSUjmYMQ1AwKAIBBAIBAQQg9gZek0mqmLc+mkHu/8FTNMkgPqYiMD/bcNO70EHMvq0wYAIBBQIBAQRYWjNwWWpnYTZvNEtzSXhnV0pyNXFPRko2aWQ3MnpvZUdKa1hCQXkweWdHaXEvaHVRbVRKN3RtUUQ0S2xMdTlZMXgyWEtrWUxsRUFLcDBZQTNaWQRpWEdTZz09MA4CAQYCAQEEBkFUVEVTVDAPAgEHAgEBBAdzYW5kYm94MB8CAQwCAQEEFzIwMjQtMDYtMjBUMDk6Mzg6MDkuNDlaMB8CARUCAQEEFzIwMjQtMDktMThUMDk6Mzg6MDkuNDlaAAAAAAAAoIAwggOuMIIDVKADAgECAhB+AhJg2M53q3KlnfBoJ779MAoGCCqGSM49BAMCMHwxMDAuBgNVBAMMJ0FwcGxlIEFwcGxpY2F0aW9uIEludGVncmF0aW9uIENBIDUgLSBHMTEmMCQGA1UECwwdQXBwbGUgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxEzARBgNVBAoMCkFwcGxlIEluYy4xCzAJBgNVBAYTAlVTMB4XDTI0MDIyNzE4Mzk1MloXDTI1MDMyODE4Mzk1MVowWjE2MDQGA1UEAwwtQXBwbGljYXRpb24gQXR0ZXN0YXRpb24gRnJhdWQgUmVjZWlwdCBTaWduaW5nMRMwEQYDVQQKDApBcHBsZSBJbmMuMQswCQYDVQQGEwJVUzBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABFQ3uILGT8UT6XpR5xJ0VeFLGpALmYvX1BaHaT8L2JPKizXqPVgjyWp1rfxMt3+SzCmZkJPZxtwtGADJAyD0e0SjggHYMIIB1DAMBgNVHRMBAf8EAjAAMB8GA1UdIwQYMBaAFNkX/ktnkDhLkvTbztVXgBQLjz3JMEMGCCsGAQUFBwEBBDcwNTAzBggrBgEFBQcwAYYnaHR0cDovL29jc3AuYXBwbGUuY29tL29jc3AwMy1hYWljYTVnMTAxMIIBHAYDVR0gBIIBEzCCAQ8wggELBgkqhkiG92NkBQEwgf0wgcMGCCsGAQUFBwICMIG2DIGzUmVsaWFuY2Ugb24gdGhpcyBjZXJ0aWZpY2F0ZSBieSBhbnkgcGFydHkgYXNzdW1lcyBhY2NlcHRhbmNlIG9mIHRoZSB0aGVuIGFwcGxpY2FibGUgc3RhbmRhcmQgdGVybXMgYW5kIGNvbmRpdGlvbnMgb2YgdXNlLCBjZXJ0aWZpY2F0ZSBwb2xpY3kgYW5kIGNlcnRpZmljYXRpb24gcHJhY3RpY2Ugc3RhdGVtZW50cy4wNQYIKwYBBQUHAgEWKWh0dHA6Ly93d3cuYXBwbGUuY29tL2NlcnRpZmljYXRlYXV0aG9yaXR5MB0GA1UdDgQWBBQrz0ke+88beQ7wrwIpE7UBFuF5NDAOBgNVHQ8BAf8EBAMCB4AwDwYJKoZIhvdjZAwPBAIFADAKBggqhkjOPQQDAgNIADBFAiEAh6gJK3RfmEDFOpQhQRpdi6oJgNSGktXW0pmZ0HjHyrUCID9lU4wTLM+IMDSwR3Xol1PPz9P3RINVupdWXH2KBoEcMIIC+TCCAn+gAwIBAgIQVvuD1Cv/jcM3mSO1Wq5uvTAKBggqhkjOPQQDAzBnMRswGQYDVQQDDBJBcHBsZSBSb290IENBIC0gRzMxJjAkBgNVBAsMHUFwcGxlIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MRMwEQYDVQQKDApBcHBsZSBJbmMuMQswCQYDVQQGEwJVUzAeFw0xOTAzMjIxNzUzMzNaFw0zNDAzMjIwMDAwMDBaMHwxMDAuBgNVBAMMJ0FwcGxlIEFwcGxpY2F0aW9uIEludGVncmF0aW9uIENBIDUgLSBHMTEmMCQGA1UECwwdQXBwbGUgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxEzARBgNVBAoMCkFwcGxlIEluYy4xCzAJBgNVBAYTAlVTMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEks5jvX2GsasoCjsc4a/7BJSAkaz2Md+myyg1b0RL4SHlV90SjY26gnyVvkn6vjPKrs0EGfEvQyX69L6zy4N+uqOB9zCB9DAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFLuw3qFYM4iapIqZ3r6966/ayySrMEYGCCsGAQUFBwEBBDowODA2BggrBgEFBQcwAYYqaHR0cDovL29jc3AuYXBwbGUuY29tL29jc3AwMy1hcHBsZXJvb3RjYWczMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuYXBwbGUuY29tL2FwcGxlcm9vdGNhZzMuY3JsMB0GA1UdDgQWBBTZF/5LZ5A4S5L0287VV4AUC489yTAOBgNVHQ8BAf8EBAMCAQYwEAYKKoZIhvdjZAYCAwQCBQAwCgYIKoZIzj0EAwMDaAAwZQIxAI1vpp+h4OTsW05zipJ/PXhTmI/02h9YHsN1Sv44qEwqgxoaqg2mZG3huZPo0VVM7QIwZzsstOHoNwd3y9XsdqgaOlU7PzVqyMXmkrDhYb6ASWnkXyupbOERAqrMYdk4t3NKMIICQzCCAcmgAwIBAgIILcX8iNLFS5UwCgYIKoZIzj0EAwMwZzEbMBkGA1UEAwwSQXBwbGUgUm9vdCBDQSAtIEczMSYwJAYDVQQLDB1BcHBsZSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTETMBEGA1UECgwKQXBwbGUgSW5jLjELMAkGA1UEBhMCVVMwHhcNMTQwNDMwMTgxOTA2WhcNMzkwNDMwMTgxOTA2WjBnMRswGQYDVQQDDBJBcHBsZSBSb290IENBIC0gRzMxJjAkBgNVBAsMHUFwcGxlIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MRMwEQYDVQQKDApBcHBsZSBJbmMuMQswCQYDVQQGEwJVUzB2MBAGByqGSM49AgEGBSuBBAAiA2IABJjpLz1AcqTtkyJygRMc3RCV8cWjTnHcFBbZDuWmBSp3ZHtfTjjTuxxEtX/1H7YyYl3J6YRbTzBPEVoA/VhYDKX1DyxNB0cTddqXl5dvMVztK517IDvYuVTZXpmkOlEKMaNCMEAwHQYDVR0OBBYEFLuw3qFYM4iapIqZ3r6966/ayySrMA8GA1UdEwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgEGMAoGCCqGSM49BAMDA2gAMGUCMQCD6cHEFl4aXTQY2e3v9GwOAEZLuN+yRhHFD/3meoyhpmvOwgPUnPWTxnS4at+qIxUCMG1mihDK1A3UT82NQz60imOlM27jbdoXt2QfyFMm+YhidDkLF1vLUagM6BgD56KyKAAAMYH9MIH6AgEBMIGQMHwxMDAuBgNVBAMMJ0FwcGxlIEFwcGxpY2F0aW9uIEludGVncmF0aW9uIENBIDUgLSBHMTEmMCQGA1UECwwdQXBwbGUgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxEzARBgNVBAoMCkFwcGxlIEluYy4xCzAJBgNVBAYTAlVTAhB+AhJg2M53q3KlnfBoJ779MA0GCWCGSAFlAwQCAQUAMAoGCCqGSM49BAMCBEcwRQIhAMqkclIRBAfFIf8FDPdDsZPWRCl+4K5JSgdQnTU1HF/qAiAOO2+7a852qfUgZsPRlGsgG+sUQKJSLY1nWvUy3NGapAAAAAAAAGhhdXRoRGF0YVik3FzsxfEkZIO81VI8567eDMSyG2Ufi1gnKTCjJgAJClVAAAAAAGFwcGF0dGVzdGRldmVsb3AAIAynfK62XZTytYfpv2cgc5CXasQXtbkZC0YdSsiWaV1vpQECAyYgASFYIIDEH9WKV4OPOLAwyV1ZFci9e9m85alDcAtgKpY/6fSaIlggbgIQ7D7KnwzgfkwhPUEBerV7XpSwbxBqSYvRkRcz81A=";

        // Decode the Base64 string
        byte[] decodedBytes = Base64.getDecoder().decode(base64String);

        // Parse the CBOR object
        CBORObject cborObject = CBORObject.DecodeFromBytes(decodedBytes);

        // Extract the certificates
        CBORObject attStmt = cborObject.get("attStmt");
        CBORObject x5c = attStmt.get("x5c");

        List<X509Certificate> certificates = new ArrayList<>();
        for (int i = 0; i < x5c.size(); i++) {
            byte[] certBytes = x5c.get(i).GetByteString();
            certificates.add(generateCertificateFromBytes(certBytes));
        }

        // Verify the certificate chain
        verifyCertificateChain(certificates);
    }

    private static X509Certificate generateCertificateFromBytes(byte[] certBytes) throws CertificateException {
        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
        return (X509Certificate) certFactory.generateCertificate(new ByteArrayInputStream(certBytes));
    }

    private static void verifyCertificateChain(List<X509Certificate> certs) throws Exception {
        // Load Apple's App Attest root certificate
        X509Certificate rootCert = loadRootCertificate();

        // Create a KeyStore with the root certificate
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null, null);
        keyStore.setCertificateEntry("apple-app-attest-root", rootCert);

        // Initialize TrustManagerFactory with the KeyStore
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(keyStore);

        // Get the X509TrustManager
        X509TrustManager trustManager = (X509TrustManager) tmf.getTrustManagers()[0];

        // Convert List<X509Certificate> to X509Certificate[]
        X509Certificate[] certArray = new X509Certificate[certs.size()];
        certs.toArray(certArray);

        // Verify the certificate chain
        trustManager.checkServerTrusted(certArray, "ECDHE_ECDSA");
        System.out.println("Certificate chain validated successfully.");
    }

    private static X509Certificate loadRootCertificate() throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader("/home/ec2-user/IosIntegrity/iOSappIntegrityaws/src/main/resources/Apple_App_Attestation_Root_CA.pem"))) {
            StringBuilder pemString = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                pemString.append(line).append("\n");
            }
            String pemCert = pemString.toString();

            // Remove the first and last lines
            pemCert = pemCert.replace("-----BEGIN CERTIFICATE-----", "")
                    .replace("-----END CERTIFICATE-----", "")
                    .replaceAll("\\s", "");

            // Decode the Base64 string
            byte[] decodedBytes = Base64.getDecoder().decode(pemCert);

            // Generate the X509Certificate from the decoded bytes
            return generateCertificateFromBytes(decodedBytes);
        }
    }
}
